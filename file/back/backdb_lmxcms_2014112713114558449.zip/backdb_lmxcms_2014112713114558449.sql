#---------------------------------------------------------#
# LMXCMS 
# version:1.4 
# Time: 2014-11-27 13:11:45 
# http://www.lmxcms.com 
# --------------------------------------------------------#


DROP TABLE IF EXISTS lmx_ad;[--end--]
CREATE TABLE `lmx_ad` (
  `id` mediumint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `extime` int(10) unsigned NOT NULL,
  `html` text NOT NULL,
  `http` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `width` mediumint(5) unsigned NOT NULL,
  `height` mediumint(5) unsigned NOT NULL,
  `exstr` text NOT NULL,
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_anli_data;[--end--]
CREATE TABLE `lmx_anli_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` mediumint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `tuijian` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remen` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  `anlipic` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `tuijian` (`tuijian`),
  KEY `remen` (`remen`),
  KEY `title` (`title`),
  KEY `list` (`id`,`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_anli_data VALUES('1','32','做一个正向价值传递者','传递,价值,正向,一个','最近有一次比较满意的经历，之所以满意，是因为尽管有曲折，最后的结果传递了正向的价值。','1417001910','','1','0','94','/file/d/chenggonganli/kuaixiao/20141126/201411261948175003.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('2','32','成为候选人的顾问，一起度过艰难时期','','小冯去S公司入职时，上头没有mgr，还是直接report给销售总监的，工作的自由度和独立性都有，但对于他这个刚从制药行业转去设备领域的人，挑战蛮大，很多工作都是初次接触，需要适应。在初入职的1个月内，我每个星期都会给他电话，不仅在工作的时间，有时晚上回家在公交车上也常会找他聊一聊。由于之前在合作职位时就已经建立了彼此信任的关系，加','1417002510','','1','0','23','/file/d/chenggonganli/kuaixiao/20141126/201411261949018464.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('3','32','帮助客户做职位的正确定位','','这个职位是客户公司新增的一个职位，职位名称是regional sales manager。职位open的背景是由于客户公司市场发展迅速，生意量过 大，需要在一个省份新增一位regional sales manager','1417002560','','1','0','76','/file/d/chenggonganli/kuaixiao/20141126/201411261949284438.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('4','33','猎头不仅仅是Business','','','1417010474','','0','0','68','/file/d/chenggonganli/kuaixiao/20141126/201411261948175003.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('5','33','真诚的价值','','','1417010495','','0','0','31','/file/d/chenggonganli/kuaixiao/20141126/201411261949018464.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('6','33','价值传递，从“信”开始','','','1417010509','','0','0','69','/file/d/chenggonganli/kuaixiao/20141126/201411261949284438.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('7','34','用专业hold住高端职位','','','1417010528','','0','0','23','/file/d/chenggonganli/kuaixiao/20141126/201411261948175003.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('8','34','我的客户，我的候选人','','','1417010542','','0','0','37','/file/d/chenggonganli/kuaixiao/20141126/201411261949018464.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('9','34','帮助客户做职位的正确定位','','','1417010554','','0','0','72','');[--end--]
INSERT INTO lmx_anli_data VALUES('10','35','猎头不仅仅是Business','','','1417010580','','0','0','24','/file/d/chenggonganli/kuaixiao/20141126/201411261948175003.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('11','35','价值传递，从“信”开始','','','1417010592','','0','0','88','/file/d/chenggonganli/kuaixiao/20141126/201411261949018464.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('12','35','我的客户，我的候选人','','','1417010606','','0','0','94','/file/d/chenggonganli/kuaixiao/20141126/201411261949284438.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('13','32','价值传递，从“信”开始','','','1417014691','','0','0','33','/file/d/chenggonganli/kuaixiao/20141126/201411261949018464.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('14','32','做一个正向价值传递者','','','1417014711','','0','0','50','/file/d/chenggonganli/kuaixiao/20141126/201411261949284438.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('15','32','做一个正向价值传递者','','','1417014728','','0','0','30','/file/d/chenggonganli/kuaixiao/20141126/201411261948175003.jpg');[--end--]
INSERT INTO lmx_anli_data VALUES('16','32','成为候选人的顾问，一起度过艰难时期','','','1417014746','','0','0','54','/file/d/chenggonganli/kuaixiao/20141126/201411261949018464.jpg');[--end--]
DROP TABLE IF EXISTS lmx_anli_data_1;[--end--]
CREATE TABLE `lmx_anli_data_1` (
  `uid` int(10) unsigned NOT NULL,
  `content` mediumtext NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_anli_data_1 VALUES('1','<p>最近有一次比较满意的经历，之所以满意，是因为尽管有曲折，最后的结果传递了正向的价值。</p><p>接手的是一家北欧500强公司专家团队的技术性职位。对于客户公司，这是一个全新的职位，在一开始，职位在职能设定和要求设置上比较模糊。然而通过沟通，我了解到，基于现实的发展，顾客的个性化要求和对未来进一步业务发展方向的规划，客户公司希望在自己的专家团队中创设一个不同以往的职位，以迎合时代，应对新的挑战。我深深明白这个职位的重要性，以及对客户公司的意义。我也明白虽然这个职位进行起来有难度，但是客户对这个职位有确实且迫切的需求，始终在给予积极关注，并能给真正适合的候选人提供很好的发展平台。而找到适合的候选人，也能为客户公司的进一步发展贡献十足的力量。<br/>&nbsp;<br/>在和客户一起分析了他们希望找到的这个人究竟来做什么事，解决什么问题后，我与Leader一起，给到了客户相关的JD修改意见。由此而展开的寻访工作中，我前前后后寻找、沟通了不少人，接触了很多优秀的工程师，针对客户公司真正缺少什么、需要什么，找怎样的人合适，我们进一步给出基于对市场了解，对客户公司了解而提出的专业性建议。由此，客户公司对职位的方向和要求作出一定的调整和改变，给到了更明晰的定义。随着职位的进行，寻访的开展，沟通的深入，要找一个怎样的人，在我心里有了日益清透明晰的模型。最后，我找到一个在日企工作的候选人。</p><p>从背景上看，他不是一个打眼的人，不是国家重点院校的本科或以上学历，英语不是非常流利，对欧美企业文化也不甚了解。在最初联系到他的时候，他甚至不了解自己做的是可被称之为MES工程师的工作……还记得他给到我的第一份简历，直接被我的Leader退回了。那是一份日企风格很重的简历，而且很绝妙的是，那些特别的部门、职称、工作内容的集合，以及对于技术特长和典型项目的几乎只字不提，使得其在众多同样做这个方向的工程师的简历中显得“别具一格”，甚至特别到使大多人不认为简历的拥有者是做这个方向的工程师。</p><p>但是通过沟通，了解到他的工作方向和内容与客户公司的职位设定一致，当进一步沟通他的项目经历时，他能细致详备又语带自豪地做出介绍，当聊及专业问题时，他能深入浅出思路明晰地做出阐述，踏实、稳重、积极、细致是他的风格。通过Reference Check，对于他的技术能力，他的钻研心，他对于机械的敏感度，他的计划性和执行力，他的英语读写能力和沟通潜力，他的责任心、协调力，有了进一步的了解。我对他有信心，我知道我没有看错人，我确信他的能力能够胜任客户公司的职位，能够做得非常出色，能够发挥他十足的能力，能够创造价值，能够树立口碑。同时，比较他现在的发展，以及客户公司能给到的平台，我确信获得这个职位能使其在技术上得到进一步提升，开阔眼界，激发还没被充分挖掘的潜能。这些不仅存在于眼前片刻，在之后很长时间，都是有意义的。此外，职位在其他部分，能给到候选人合理的提升，因此我认为，候选人和这个职位非常匹配。于是，还是沟通，去做一些解释，去探究一些原因，给到一些简历做参考，给到一些建议，我获得了第二份简历。又做了一些修改，比令人印象深刻的第一份简历，是有了不少忠于现实的长足变化了。</p><p>只是，正如一开始所说的，不是耀眼的背景，前后两份简历又有不少的变化，一开始公司内部审核觉得不是很适合，对推荐给客户这一行为持谨慎态度。于我，只说了一句：这个人非常好非常适合，我对他有信心。</p><p>之后，客户收到报告后存在Concern，一开始不愿意面试。感谢我的Leader，感谢他对我的信任，为我建立联系，让我写邮件为候选人做了积极争取。再之后是面试官不在上海，是候选人出差险些安排不了面试，是英语测试有一定难度，是确认沟通。好在，一步一步，有惊有险，但走到最后。</p><p>祝贺候选人，觅得好的平台。祝贺客户公司，觅得良才。祝贺自己，为了分辨、相信和坚持，为了这小小的一次成功和从中收获的点滴感动，为了这一次正向价值的传递。 <br/>我一直希望我的工作是传递正向价值，是发现最适合的人才并给予发展平台，是解放生产力，是促成良性竞争，是对行业对社会存在意义的行为。一如“拓优”所一直倡导并坚持的：价值优先，共享成功。</p><p>我们顾问做单，要在最短的时间，找到最适合客户公司岗位的人，找到能真正给客户公司带去裨益的人，干出实事的人，作出贡献的人。同样，顾问推荐的职位，之所以能被称之为适合，是因为对候选人来说是能发挥他们的长处，展现他们的积累，满足他们的发展要求，同时能在特定的一些方面给予一定合理提高的。尤其对于有实力却被市场过分低估的候选人，这样成功的一单，每每能让我开心很久很久，是在这个急速的缭乱的疏离的世界里，为素未平生的即亲近又疏远的优秀人才感到的真正的高兴与感动，以及对其未来良好发展的真挚祝福。这种成就和欢乐，无法言说。</p><p>很多时候，我们的生活就好比一个战场，如果你想要得到一样东西，就必须拼命去争取。需要忘掉所有那些“不可能”的借口，去坚持那一个“可能”。而支持你不畏艰难，不畏困苦，即使劳累，也要坚持下去的理由，是发自内心的坚定认可。对于我，是认可顾问行业存在的意义，认可顾问工作的重要性、认可共建双赢，认可这些年“拓优”教诲我的：去做一个正向价值的传递者。</p><p>&nbsp;</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('2','<p>小冯去S公司入职时，上头没有mgr，还是直接report给销售总监的，工作的自由度和独立性都有，但对于他这个刚从制药行业转去设备领域的人，挑战蛮
大，很多工作都是初次接触，需要适应。在初入职的1个月内，我每个星期都会给他电话，不仅在工作的时间，有时晚上回家在公交车上也常会找他聊一聊。由于之
前在合作职位时就已经建立了彼此信任的关系，加上后期坦诚的沟通，我对他的想法倒还是能够及时掌握。&nbsp;<br/><br/>每次电话结束时他都会表一下态：“虽然有困难，但我会坚持做出成绩。”&nbsp;<br/><br/>入职1个半月后，听说他上头来了一个mgr。一个是突然空降过来的经理，一个是已经有些资历的销售，在磨合期阶段，应该说也是个“多事之秋”的时期，两个人配合的怎样呢？他怎么看待这个新上任的直线经理呢？……应该是要好好聊一下了。&nbsp;<br/><br/>小冯说mgr人不错，在工作上给了他很多辅导和帮助，但现在面临的最大困难是和他磨合的挑战。对mgr有时做事的方式方法不太认可，感觉他是那种事事要求完美。BALABALA，很多小细节，很多小事。&nbsp;<br/><br/>小冯知道mgr应该是为他好，希望他做出业绩，但可能因为他确实缺乏设备行业的经验，两人的沟通有时不顺畅。但他认为自己是在不断进步的，每次冲突的时候，他也会从自己身上找原因，是不是哪些地方做的不好。&nbsp;<br/><br/>小
冯认为，S公司的文化是他特别认可的，可以说是“不谋而合”，快乐的做事，发挥长处。做的事情是自己的特长那么做起来也会觉得特别有劲。被信任，他会付出
120%的努力。他也认为S公司的平台是非常好的，也会认真的干下去，至少1年内他是这样想的，而且他特别想做出点成绩，因为觉得从开始应聘这个职位到现
在，面试啊offer啊培训啊什么的，花了公司不少钱，而自己还没有能够给公司带来利益呢，会觉得很愧疚。&nbsp;<br/><br/>从这次的沟通中我获得了非常重要的信息：小冯和空降的mgr之间确实存在问题，但同时，他的心态是非常正向和积极的。这一点很关键。<br/><br/>


 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;但这毕竟是一个双向的事情，如果下属认为和直线经理的配合有问题，想必mgr对他也是不满意的。但这个mgr并不是我们offer的，之前也从未接触过，
如果贸然联系沟通这个问题，彼此没有信任的基础，不会有好效果，有可能还会有反效果。不过这些情况倒可以适当反映给HR。候选人入职后的跟进，协助候选人
快速适应新环境，及时发现问题并帮助解决，促进双方新的合作的顺利进行，这是我们的工作内容之一，更是我们服务流程中很关键的一个环节。&nbsp;<br/><br/>果不其然，mgr对小冯有很多微词，已经告到总监那儿了，说小冯的工作有问题，准备让他走人，结果被总监一句话堵了回来：“你刚来上班，不想着怎么把业务做起来，倒想着炒人？”毕竟这是总监亲自挑中的人，说他有问题，这不等于说总监的眼光有问题么……&nbsp;<br/><br/>此后，相安无事的一个月又过去了。<br/>&nbsp;<br/>三个月的保质期眼看着过去了。可跟进的工作还是不能停，这事情不明朗我总是放心不下。给候选人推荐职位是希望他能有个好的发展，给客户推荐候选人是希望这个人能够给客户公司带来正向的价值。这才能担得起“猎头顾问”这个名字。于是我又打了小冯的电话。<br/>&nbsp;<br/>小
冯说，工作中还是有些挑战的，跟mgr的关系比原来好了点，一直觉得mgr人是不错的，可能之前所在的公司文化特征太鲜明了，所以导致了相处中的一些小摩
擦。现在的工作开展已经有了一点成绩，代理商的关系也理顺了，后面的工作重点可能要在大客户这边多下下功夫，因为设备涉及的金额特别大，需要院领导、省级
领导这些高层拍板，他们不愿意相信外人。但整体看来都是向着好的方向前进，今年应该是能够完成任务的。对于S公司还是像之前一样，希望自己要做出点成绩
来，至少要再坚持一个季度看看，如果不做点成绩出来会觉得很抱歉。&nbsp;<br/><br/>我悬着的心稍稍放下了。<br/><br/>


 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;5天后&nbsp;<br/><br/>突然接到小冯的电话，说和mgr的相处已经到了不能忍受的地步，mgr没有基本的信任感。只要他有一次
电话没有接到，就打到代理商去问他的行踪。并且要求他直接去代理商的办事处去上班，还曾经跟代理商交代过，说要查他。这对一个“工作内容之一是管理代理
商”的人，是多么困难的事情，可想而知小冯的艰难处境。<br/>&nbsp;<br/>小冯说自己一直在努力适应mgr的管理方式和做事风格，也希望能够达到很好的合
作状态，可是mgr的这些做法他实在无法再认同下去。他表示自己一直很珍惜这个工作机会，也非常希望能做出成绩在这里有一个很好的发展。我问他如果换个部
门换个经理他是否考虑在这里长期做下去，他表示还是有很大的顾虑，毕竟还在同一个公司，如果mgr确实是针对他的话换部门也没有用。我又问他如果这个
mgr不在S公司他是否会考虑在这里长期做下去，他是非常乐意的。但小冯接着表示自己不敢也不能这样想，自己和mgr都是公司招来的，都花费了比较大的成
本，如果非要走一个人的话，他宁肯是自己。维持现状不变，他只有再撑1个月。目前没有应聘任何公司的职位。说现在没心思想这些事情，一心就只在工作中
了。&nbsp;<br/><br/>又过了几天，小冯给我电话，说他很想马上离职，即使没有工作也要离开。说他以前公司共事的老板要去一家新公司了，到时候会找他过去。&nbsp;<br/><br/>说
实话到这里我早就可以放弃不管了，因为如果按照和客户的合同约定，早就过了保质期，而且他目前的处境很大一部分原因是来自于政治斗争，空降的经理要组建自
己的团队，清除异己，这也不是我这个层面能解决得了的问题。客户能解决，但对于他们而言，如果必须有一个人要离开，小冯一定是个牺牲品。&nbsp;<br/><br/>我还是很真诚的告诉给他，职业空档期对他来说是很危险的，尤其他所在的城市是二线城市，从我们以往的招聘情况来看，从人才市场的需求来看，合适他的职业选择并不多。同时，我也把这几次跟进的情况再次做了整理，将客观的情况呈现给HR。<br/><br/>


 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;又一个周五，周会上听同事分享了一个案例，说的就是候选人在新公司磨合期出了问题，因为有诸多的不适应，恰好这时之前的老板找他回去帮忙，他就答应了，和
新公司提了离职。但回去之后发现，因为他之前的离开，和原老板之前的那种合作和信任其实早不复存在了，根本不是他想的那样，很后悔离开新的公司。&nbsp;<br/><br/>当天会议结束后，我就立马打电话给小冯，把这个案例分享给他，没别的意思，就是希望他在选择的时候，能够谨慎。&nbsp;<br/><br/>几天后，小冯给我发了很长的一条手机短信，大体意思是说谢谢我一直以来和他的沟通，他决定在公司里好好做下去，就当做一个磨练。他相信会有一个好的结果。

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('3','<p>这个职位是客户公司新增的一个职位，职位名称是regional&nbsp;sales&nbsp;manager。职位open的背景是由于客户公司市场发展迅速，生意量过
大，需要在一个省份新增一位regional&nbsp;sales&nbsp;manager。希望这个候选人有本科以上的学历，有着丰富的渠道管理经验，善于做深度分销，
有着成功的大团队管理经验，同时还要精通重点客户管理，善于生意的布局，有一定的战略性思维。&nbsp;<br/><br/>接到这个职位以后，由于window是我自己，按照JD阅读技术做好职位的分析，同客户确认了需求，明确了我们所选择的候选人是来自于快速消费行业，有着丰富的销售管理经验，同时情商较高，善于市场布局。&nbsp;<br/><br/>需求明确后，我开始了市场的寻访工作。这个省对我来说相对比较陌生，基本没有寻访过该地区的候选人。尤其客户需要这个候选人能够有过两个以上省份的市场管理经验，在该地区还是很少有这样类型的候选人在当地的。&nbsp;<br/><br/>其实寻访对我来说并不困难。问题有两个：一是市场中没有完全能够符合客户要求的候选人，尤其在大区域管理上；二是候选人对于客户品牌的信心不足。&nbsp;<br/><br/>我
先将能够满足客户需求的候选人找出来，实际市场中在该区域没有公司会放候选人同时管理两个以上的省份。讲市场的真实情况，写出寻访报告给到客户，同客户沟
通，拓优的企业精神是共享成功，是客户和我们，以及候选人三方的成功，而且是希望我们能够帮助客户找到最合适的候选人。在我们反复同客户的
line&nbsp;manager和HR沟通之后，客户也认可我们的思路。讲目标候选人定位在有过管理一个省份的成功经验就可以。<br/><br/>



 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;将自己的目标圈扩大到管理一个省的候选人之后，对优秀候选人客观的分析客户品牌的价值，帮助候选人从行业角度，目前候选人所在公司和客户所在公司发展角
度，真正的从候选人的职业发展出发帮助候选人客观分析该职位的价值。终于推荐出三位motivation正向，背景符合客户要求的候选人。&nbsp;<br/><br/>经
过五轮的面试，从HR到GM，终于有一位候选人得到客户的认可，可以进入到offer的流程。但在offer的数字出了很严重的问题。客户给到候选人的数
字不仅仅和候选人的期望值相距甚远，实际上等于没有提升。毕竟客户公司有自己一定的薪酬福利体系。经过我同客户的再三沟通，最后略微有一定的提升。但相对
候选人来说还是不太满意的。我同候选人沟通过数次不谈，并且发动一切能够可以发动的力量，请HR和hiring&nbsp;manager同候选人分别做了深入沟
通，最后候选人也真正的被客户的诚意所打动。尽管候选人的薪酬没有很大的提升，但相对职业发展和更加认可的老板，最终候选人还是接受了客户公司的
offer。&nbsp;<br/><br/>在接下来的流程中，给候选人认真的离职辅导，离职过程中每周都跟进候选人的情况，看候选人有否遇到相关问题，在每个问题上
给到候选人相关建议。离职中也有一段小插曲，由于候选人在原来公司服务10年，和原来的上司也合作了近10年，并且候选人还是公司重点培养的员工，公司有
着强烈的挽留。过程中我将自己的看法给到候选人，同时将候选人目前离职的情况和所遇到的问题也反馈给客户，我和客户都共同作用于候选人，在候选人离职的决
心上，面对问题时的处理方式上都给到了很充分的建议，最终使得候选人可以顺利入职。<br/><br/>



 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;过程中有着很多的波折，但经过我们和客户专业，信任和真诚最终获得了成功。对于我们来说，我们收获了客户和候选人双方的认可。当市场的人力资源情况和客户
的需求不符合时，顾问和window应该敢于给到客户公司建议，发挥我们应有的影响力，这才是顾问应该做到的。&nbsp;<br/><br/>在整个职位的操作过程
中，重点在于我们秉承着拓优作为优秀的猎头公司，是真正的客户企业人力资源解决方案的提供商，我们没有为了只是成功职位而做单，而是真正的为客户着想，从
客户的实际需求出发，认真帮助客户做职位的JD分析，行业分析和当地市场分析，准确确定目标圈，通过六问来准确寻访候选人。方法论和创新精神是在职位寻访
过程中，同客户沟通的过程中最有力的体现，客户也更加清楚了拓优的操作特点和方法，也更好的给到客户更多的信心。同时，诚信也成为拓优在推荐候选人的标
志。

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('4','<p>猎头不仅仅是Business</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('5','<p>真诚的价值</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('6','<p>价值传递，从“信”开始</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('7','<p>用专业hold住高端职位</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('8','<p>我的客户，我的候选人</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('9','<p>帮助客户做职位的正确定位</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('10','<p>猎头不仅仅是Business</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('11','<p>价值传递，从“信”开始</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('12','<p>我的客户，我的候选人</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('13','<p>价值传递，从“信”开始</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('14','<p>做一个正向价值传递者</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('15','<p>做一个正向价值传递者</p>');[--end--]
INSERT INTO lmx_anli_data_1 VALUES('16','<p>成为候选人的顾问，一起度过艰难时期</p>');[--end--]
DROP TABLE IF EXISTS lmx_book;[--end--]
CREATE TABLE `lmx_book` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `mail` varchar(255) NOT NULL,
  `tel` varchar(30) NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `ischeck` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_book VALUES('9','诗圣杜甫阿斯蒂芬','127.0.0.1','爱的色放','诗圣杜甫阿斯蒂芬','123123','1409151994','0','1');[--end--]
INSERT INTO lmx_book VALUES('6','测试姓名','127.0.0.1','测试留言内容','111111@16.com','123456789','1409149063','0','0');[--end--]
INSERT INTO lmx_book VALUES('7','测试姓名','127.0.0.1','测试留言内容','123123@126.com','213123','1409149077','0','1');[--end--]
INSERT INTO lmx_book VALUES('8','admin','','测试管理员回复','','','1409149097','7','0');[--end--]
DROP TABLE IF EXISTS lmx_cj;[--end--]
CREATE TABLE `lmx_cj` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `mid` mediumint(5) unsigned NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_cj_data;[--end--]
CREATE TABLE `lmx_cj_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lid` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `uid` mediumint(5) unsigned NOT NULL,
  `url` varchar(255) NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `is_in` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lid` (`lid`),
  KEY `uid` (`uid`),
  KEY `is_in` (`is_in`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_cj_list;[--end--]
CREATE TABLE `lmx_cj_list` (
  `lid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lname` varchar(255) NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `array` text NOT NULL,
  `url_str` text NOT NULL,
  `classid` mediumint(5) unsigned NOT NULL,
  `lcontent` varchar(255) NOT NULL,
  `is_fenci_tags` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `num` int(10) unsigned NOT NULL DEFAULT '0',
  `time_jg` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `is_info_page` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `info_page_regular` text NOT NULL,
  `content_url_box` text NOT NULL,
  `content_url_regular` text NOT NULL,
  `ztid` varchar(255) NOT NULL,
  `tagsname` varchar(255) NOT NULL,
  `str_y_replace` varchar(255) NOT NULL,
  `str_n_replace` varchar(255) NOT NULL,
  `str_remove` text NOT NULL,
  `remove_html` varchar(255) NOT NULL,
  `list_dy_url` text NOT NULL,
  `list_url_tem` varchar(255) NOT NULL,
  `pre_page` varchar(255) NOT NULL,
  `fix_page` varchar(255) NOT NULL,
  `start_page` int(10) unsigned NOT NULL DEFAULT '0',
  `end_page` int(10) unsigned NOT NULL DEFAULT '0',
  `jg_page` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `desc_page` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remove_page_fix` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`lid`),
  KEY `rid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_cj_url;[--end--]
CREATE TABLE `lmx_cj_url` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `urlmd5` char(32) NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `lid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `urlmd5` (`urlmd5`),
  KEY `lid` (`lid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_column;[--end--]
CREATE TABLE `lmx_column` (
  `classid` mediumint(5) unsigned NOT NULL AUTO_INCREMENT,
  `uid` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `classname` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `mid` mediumint(5) unsigned NOT NULL,
  `classtype` tinyint(1) NOT NULL DEFAULT '0',
  `classpath` varchar(100) NOT NULL,
  `classurl` varchar(255) NOT NULL,
  `listtem` varchar(50) NOT NULL,
  `contem` varchar(50) NOT NULL,
  `searchtem` varchar(50) NOT NULL,
  `singletem` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `images` varchar(255) NOT NULL,
  `pagenum` mediumint(5) unsigned NOT NULL,
  `display` tinyint(1) NOT NULL DEFAULT '0',
  `islist` tinyint(1) unsigned NOT NULL COMMENT '是否为列表分页',
  `domain` varchar(255) NOT NULL,
  PRIMARY KEY (`classid`),
  KEY `uid` (`uid`),
  KEY `mid` (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_column VALUES('1','0','关于仕扬','关于仕扬','0','1','about.html','','','','','about','关于仕扬','关于仕扬','0','','0','0','0','');[--end--]
INSERT INTO lmx_column VALUES('3','1','公司简介','公司简介','0','1','gongsijianjie.html','','','','','about','公司简介','公司简介','0','/file/cate/20141126/201411261550485333.jpg','0','0','0','');[--end--]
INSERT INTO lmx_column VALUES('4','1','企业文化','企业文化','0','1','qiyewenhua.html','','','','','about','企业文化','企业文化','0','','0','0','0','');[--end--]
INSERT INTO lmx_column VALUES('36','0','最新职位','最新职位','4','0','zuixinzhiwei','','zhiwei_list','zhiwei_lerong','index','','最新职位','最新职位','0','','10','0','1','');[--end--]
INSERT INTO lmx_column VALUES('31','0','成功案例','成功案例','3','0','chenggonganli','','anli','anli','index','','成功案例','成功案例','0','','10','0','1','');[--end--]
INSERT INTO lmx_column VALUES('32','31','快速消费品','快速消费品','3','0','chenggonganli/kuaisuxiaofeipin','','anli_list','anli_lerong','index','','快速消费品','快速消费品','0','/file/cate/20141126/201411262157431134.jpg','6','0','1','');[--end--]
INSERT INTO lmx_column VALUES('33','31','大工业制造','大工业制造','3','0','chenggonganli/dagongyezhizao','','anli_list','anli_lerong','index','','大工业制造','大工业制造','0','/file/cate/20141126/201411262158309889.jpg','6','0','1','');[--end--]
INSERT INTO lmx_column VALUES('34','31','通讯IT互联网','IT通讯互联网','3','0','chenggonganli/tongxunhulianwang','','anli_list','anli_lerong','index','','IT通讯互联网','IT通讯互联网','0','/file/cate/20141126/201411262159075161.jpg','6','0','1','');[--end--]
INSERT INTO lmx_column VALUES('35','31','金融与房地产','金融','3','0','chenggonganli/jinrong','','anli_list','anli_lerong','index','','金融','金融','0','/file/cate/20141126/201411262159431636.jpg','6','0','1','');[--end--]
INSERT INTO lmx_column VALUES('16','1','公司愿景','公司愿景','0','1','gongsiyuanjing.html','','','','','about','公司愿景','公司愿景','0','','0','0','0','');[--end--]
INSERT INTO lmx_column VALUES('38','36','公司内部职位','公司内部职位','4','0','zuixinzhiwei/gongsineibuzhiwei','','zhiwei_list','zhiwei_lerong','index','','公司内部职位','公司内部职位','0','','10','0','1','');[--end--]
INSERT INTO lmx_column VALUES('37','36','合作客户职位','合作客户职位','4','0','zuixinzhiwei/hezuokehuzhiwei','','zhiwei_list','zhiwei_lerong','index','','合作客户职位','合作客户职位','0','','10','0','1','');[--end--]
INSERT INTO lmx_column VALUES('28','26','服务流程','服务流程','0','1','fuwuliucheng.html','','','','','hz','服务流程','服务流程','0','','0','0','0','');[--end--]
INSERT INTO lmx_column VALUES('29','26','选择仕扬','选择仕扬','0','1','xuanzeshiyang.html','','','','','hz','选择仕扬','选择仕扬','0','','0','0','0','');[--end--]
INSERT INTO lmx_column VALUES('30','26','其他解决方案','其他解决方案','0','1','qitajiejuefangan.html','','','','','hz','其他解决方案','其他解决方案','0','','0','0','0','');[--end--]
INSERT INTO lmx_column VALUES('26','0','企业合作','企业合作','0','1','qiyehezuo.html','','','','','hz','企业合作','企业合作','0','','0','0','0','');[--end--]
INSERT INTO lmx_column VALUES('27','26','专注领域','专注领域','0','1','zhuanzhulingyu.html','','','','','hz','专注领域','专注领域','0','','0','0','0','');[--end--]
INSERT INTO lmx_column VALUES('39','0','轮播广告','','5','0','lunboguanggao','','product','product','index','','','','0','','10','1','1','');[--end--]
INSERT INTO lmx_column VALUES('41','0','猎头委托','猎头委托','0','1','lietouweituo.html','','','','','weituo','猎头委托','猎头委托','0','','0','1','0','');[--end--]
INSERT INTO lmx_column VALUES('42','1','联系我们','联系我们','0','1','lianxiwomen.html','','','','','about','上海：虹口区大连路535号3楼A36         
北京：朝阳区朝阳门外大街18号丰联广场A座1906      
武汉：武昌区中南路7号中商广场3402     
电话：021-65356632-9036','联系我们','0','','0','0','0','');[--end--]
DROP TABLE IF EXISTS lmx_dyfield;[--end--]
CREATE TABLE `lmx_dyfield` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fieldtype` varchar(255) NOT NULL,
  `fieldname` varchar(255) NOT NULL,
  `fieldtitle` varchar(255) NOT NULL,
  PRIMARY KEY (`fid`),
  KEY `fieldname` (`fieldname`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_dyfield VALUES('1','text','gsmc','公司名称');[--end--]
INSERT INTO lmx_dyfield VALUES('5','text','tel','联系电话');[--end--]
INSERT INTO lmx_dyfield VALUES('4','text','lxr','联系人');[--end--]
INSERT INTO lmx_dyfield VALUES('6','text','mobile','手机号码');[--end--]
INSERT INTO lmx_dyfield VALUES('7','text','email','邮箱地址');[--end--]
INSERT INTO lmx_dyfield VALUES('9','textarea','miaoshu','需求描述');[--end--]
DROP TABLE IF EXISTS lmx_dyform;[--end--]
CREATE TABLE `lmx_dyform` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `formname` varchar(255) NOT NULL,
  `must` varchar(255) NOT NULL,
  `fieldid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_dyform VALUES('2','猎头委托','miaoshu,tel,lxr','9,7,6,5,4,1');[--end--]
DROP TABLE IF EXISTS lmx_dyformcon;[--end--]
CREATE TABLE `lmx_dyformcon` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL,
  `ip` varchar(20) NOT NULL,
  `gsmc` varchar(255) NOT NULL,
  `lxr` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `miaoshu` text NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_dyformcon VALUES('1','2','1417017727','127.0.0.1','久鑫网络','李勇','11111111111','11111111111','11@163.com','11111');[--end--]
DROP TABLE IF EXISTS lmx_field;[--end--]
CREATE TABLE `lmx_field` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` mediumint(5) unsigned NOT NULL,
  `fname` varchar(20) NOT NULL,
  `ftitle` varchar(100) NOT NULL,
  `ftype` varchar(50) NOT NULL,
  `ismust` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `defaults` text NOT NULL,
  `vice` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `mid` (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_field VALUES('1','1','content','正文','editor','0','0','','1');[--end--]
INSERT INTO lmx_field VALUES('2','2','content','正文','editor','0','0','','1');[--end--]
INSERT INTO lmx_field VALUES('3','1','pic','产品图片','image','0','2','','0');[--end--]
INSERT INTO lmx_field VALUES('4','1','duotp','产品图片集','moreimage','0','1','','0');[--end--]
INSERT INTO lmx_field VALUES('5','3','content','正文','editor','0','0','','1');[--end--]
INSERT INTO lmx_field VALUES('6','3','anlipic','标题图片','image','0','0','','0');[--end--]
INSERT INTO lmx_field VALUES('9','5','lbpic','图片','image','1','0','','0');[--end--]
INSERT INTO lmx_field VALUES('10','4','bianhao','职位编号','text','0','10','','0');[--end--]
INSERT INTO lmx_field VALUES('11','4','zwmc','职位名称','text','0','9','','0');[--end--]
INSERT INTO lmx_field VALUES('12','4','gzms','雇主描述','editor','0','0','','0');[--end--]
INSERT INTO lmx_field VALUES('13','4','gzdd','工作地点','text','0','8','','0');[--end--]
INSERT INTO lmx_field VALUES('14','4','lxgw','联系顾问','text','0','7','','0');[--end--]
INSERT INTO lmx_field VALUES('15','4','lianxin','年薪','text','0','5','','0');[--end--]
INSERT INTO lmx_field VALUES('16','4','gsmc','公司名称','text','0','0','','0');[--end--]
DROP TABLE IF EXISTS lmx_file;[--end--]
CREATE TABLE `lmx_file` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0为图片 1为文件',
  `name` varchar(255) NOT NULL,
  `temname` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `size` varchar(50) NOT NULL,
  `issmall` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `filepath` (`path`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_file VALUES('4','0','201408271642357617.jpg','1.jpg','/file/d/product/20140827/201408271642357617.jpg','1409128955','20.74KB','0');[--end--]
INSERT INTO lmx_file VALUES('2','0','201408271523025580.jpg','2.jpg','/file/slide/20140827/201408271523025580.jpg','1409124182','87.73KB','0');[--end--]
INSERT INTO lmx_file VALUES('3','0','201408271523022322.jpg','3.jpg','/file/slide/20140827/201408271523022322.jpg','1409124182','49.47KB','0');[--end--]
INSERT INTO lmx_file VALUES('5','0','201408271644398005.jpg','2.jpg','/file/d/product/20140827/201408271644398005.jpg','1409129079','21.25KB','0');[--end--]
INSERT INTO lmx_file VALUES('6','0','201408271645056451.jpg','3.jpg','/file/d/product/20140827/201408271645056451.jpg','1409129105','21.5KB','0');[--end--]
INSERT INTO lmx_file VALUES('7','0','201408271649165919.jpg','4.jpg','/file/d/product/20140827/201408271649165919.jpg','1409129356','25.74KB','0');[--end--]
INSERT INTO lmx_file VALUES('8','0','201411261550485333.jpg','1.jpg','/file/cate/20141126/201411261550485333.jpg','1416988249','49.18KB','0');[--end--]
INSERT INTO lmx_file VALUES('9','0','201411261615212753.jpg','banner.jpg','/file/slide/20141126/201411261615212753.jpg','1416989722','197.38KB','0');[--end--]
INSERT INTO lmx_file VALUES('10','0','201411261615532055.jpg','banner.jpg','/file/slide/20141126/201411261615532055.jpg','1416989754','197.38KB','0');[--end--]
INSERT INTO lmx_file VALUES('11','0','201411261621595238.jpg','banner.jpg','/file/ad/20141126/201411261621595238.jpg','1416990120','197.38KB','0');[--end--]
INSERT INTO lmx_file VALUES('12','0','201411261623002779.jpg','banner.jpg','/file/ad/20141126/201411261623002779.jpg','1416990181','197.38KB','0');[--end--]
INSERT INTO lmx_file VALUES('13','0','201411261623437086.jpg','banner.jpg','/file/ad/20141126/201411261623437086.jpg','1416990224','197.38KB','0');[--end--]
INSERT INTO lmx_file VALUES('14','0','201411261939285488.jpg','2.jpg','/file/d/chenggonganli/kuaixiao/20141126/201411261939285488.jpg','1417001969','29.29KB','0');[--end--]
INSERT INTO lmx_file VALUES('15','0','201411261948175003.jpg','1.jpg','/file/d/chenggonganli/kuaixiao/20141126/201411261948175003.jpg','1417002498','20.3KB','0');[--end--]
INSERT INTO lmx_file VALUES('16','0','201411261949018464.jpg','2.jpg','/file/d/chenggonganli/kuaixiao/20141126/201411261949018464.jpg','1417002542','19.53KB','0');[--end--]
INSERT INTO lmx_file VALUES('17','0','201411261949284438.jpg','3.jpg','/file/d/chenggonganli/kuaixiao/20141126/201411261949284438.jpg','1417002569','23.15KB','0');[--end--]
INSERT INTO lmx_file VALUES('18','0','201411262109384671.jpg','11.jpg','/file/link/20141126/201411262109384671.jpg','1417007379','34.26KB','0');[--end--]
INSERT INTO lmx_file VALUES('19','0','201411262110079723.jpg','22.jpg','/file/link/20141126/201411262110079723.jpg','1417007408','30.39KB','0');[--end--]
INSERT INTO lmx_file VALUES('20','0','201411262110264477.jpg','33.jpg','/file/link/20141126/201411262110264477.jpg','1417007427','29.62KB','0');[--end--]
INSERT INTO lmx_file VALUES('21','0','201411262110587899.jpg','44.jpg','/file/link/20141126/201411262110587899.jpg','1417007459','31.47KB','0');[--end--]
INSERT INTO lmx_file VALUES('22','0','201411262111206955.jpg','55.jpg','/file/link/20141126/201411262111206955.jpg','1417007481','30.42KB','0');[--end--]
INSERT INTO lmx_file VALUES('23','0','201411262157431134.jpg','01.jpg','/file/cate/20141126/201411262157431134.jpg','1417010264','55.07KB','0');[--end--]
INSERT INTO lmx_file VALUES('24','0','201411262158309889.jpg','02.jpg','/file/cate/20141126/201411262158309889.jpg','1417010311','38.39KB','0');[--end--]
INSERT INTO lmx_file VALUES('25','0','201411262159075161.jpg','03.jpg','/file/cate/20141126/201411262159075161.jpg','1417010348','41.86KB','0');[--end--]
INSERT INTO lmx_file VALUES('26','0','201411262159431636.jpg','04.jpg','/file/cate/20141126/201411262159431636.jpg','1417010384','42.04KB','0');[--end--]
DROP TABLE IF EXISTS lmx_link;[--end--]
CREATE TABLE `lmx_link` (
  `id` mediumint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `isimg` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `remarks` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `isimg` (`isimg`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_link VALUES('3','中国腾达','http://www.baidu.com','/file/link/20141126/201411262109384671.jpg','1','0','');[--end--]
INSERT INTO lmx_link VALUES('4','我国资讯','http://','/file/link/20141126/201411262110079723.jpg','1','0','');[--end--]
INSERT INTO lmx_link VALUES('5','明泰消防','http://','/file/link/20141126/201411262110264477.jpg','1','0','');[--end--]
INSERT INTO lmx_link VALUES('6','家立电子','http://','/file/link/20141126/201411262110587899.jpg','1','0','');[--end--]
INSERT INTO lmx_link VALUES('7','华为','http://','/file/link/20141126/201411262111206955.jpg','1','0','');[--end--]
INSERT INTO lmx_link VALUES('8','中国腾达','http://','/file/link/20141126/201411262109384671.jpg','1','0','');[--end--]
INSERT INTO lmx_link VALUES('9','中国腾达','http://','/file/link/20141126/201411262110264477.jpg','1','0','');[--end--]
INSERT INTO lmx_link VALUES('10','明泰消防','http://','/file/link/20141126/201411262111206955.jpg','1','0','');[--end--]
INSERT INTO lmx_link VALUES('11','明泰消防','http://','/file/link/20141126/201411262110587899.jpg','1','0','');[--end--]
INSERT INTO lmx_link VALUES('12','明泰消防','http://','/file/link/20141126/201411262109384671.jpg','1','0','');[--end--]
DROP TABLE IF EXISTS lmx_log;[--end--]
CREATE TABLE `lmx_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `time` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `userip` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=193 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_log VALUES('1','【admin】登录后台','1416972878','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('2','【admin】登录后台','1416972951','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('3','修改【天健文化】栏目','1416973218','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('4','修改【企业理念】栏目','1416973388','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('5','修改【公司简介】栏目','1416973412','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('6','增加栏目【组织架构】','1416973434','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('7','修改【组织架构】栏目','1416973461','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('8','增加栏目【大事记】','1416973506','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('9','增加栏目【员工之家】','1416973655','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('10','修改【员工之家】栏目','1416973781','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('11','修改【中医馆】栏目','1416973839','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('12','修改【名医简介】栏目','1416973872','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('13','修改【药材辨识】栏目','1416973930','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('14','增加栏目【四季养生】','1416974021','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('15','增加栏目【春季养生】','1416974058','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('16','增加栏目【夏季养生】','1416974089','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('17','增加栏目【秋季养生】','1416974121','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('18','增加栏目【冬季养生】','1416974171','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('19','增加栏目【慢病生活馆】','1416974201','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('20','增加栏目【风湿病】','1416974229','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('21','创建采集节点','1416974298','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('22','删除节点以及节点采集规则和网址库和规则数据','1416974317','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('23','【admin】登录后台','1416985255','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('24','修改【关于仕扬】栏目','1416985297','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('25','修改【公司简介】栏目','1416985324','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('26','修改【企业文化】栏目','1416985344','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('27','修改【公司愿景】栏目','1416985366','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('28','删除栏目【id：17】和所属信息','1416985437','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('29','删除栏目【id：18】和所属信息','1416985445','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('30','删除栏目【id：14,11,13,12,5】和所属信息','1416985459','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('31','删除栏目【id：7,8,6】和所属信息','1416985505','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('32','删除栏目【id：23,20,22,21,19】和所属信息','1416985511','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('33','删除栏目【id：25,24】和所属信息','1416985519','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('34','增加栏目【企业合作】','1416985829','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('35','增加栏目【专注领域】','1416985854','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('36','增加栏目【服务流程】','1416985874','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('37','增加栏目【选择仕扬】','1416985896','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('38','增加栏目【其他解决方案】','1416985920','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('39','增加系统模型【成功案例】','1416985991','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('40','增加字段—模型id：【3】—字段名字：【anlipic】','1416986090','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('41','增加栏目【成功案例】','1416986397','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('42','增加栏目【快消】','1416986439','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('43','增加栏目【大制造】','1416986464','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('44','增加栏目【IT通讯互联网】','1416986591','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('45','增加栏目【金融】','1416986629','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('46','增加系统模型【职位】','1416986659','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('47','增加栏目【最新职位】','1416986746','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('48','增加栏目【合作客户职位】','1416986776','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('49','增加栏目【公司内部职位】','1416986858','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('50','【admin】登录后台','1416988223','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('51','修改【公司简介】栏目','1416988261','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('52','修改焦点图片','1416989727','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('53','修改焦点图片','1416989758','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('54','增加广告','1416990142','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('55','增加广告','1416990193','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('56','增加广告','1416990268','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('57','删除广告【id：1】','1416990448','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('58','删除广告【id：2】','1416990454','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('59','删除广告【id：3】','1416990460','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('60','增加系统模型【轮播广告】','1416990493','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('61','删除字段【mid：5、fid:8】','1416990505','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('62','增加字段—模型id：【5】—字段名字：【lbpic】','1416990550','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('63','增加栏目【轮播广告】','1416990589','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('64','增加信息【classid：39】','1416990617','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('65','增加信息【classid：39】','1416990637','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('66','增加信息【classid：39】','1416990659','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('67','修改信息【classid：39】【id：2】','1416994135','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('68','修改信息【classid：39】【id：2】','1416994158','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('69','【admin】登录后台','1417000242','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('70','增加信息【classid：32】','1417002005','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('71','修改信息【classid：32】【id：1】','1417002504','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('72','增加信息【classid：32】','1417002547','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('73','增加信息【classid：32】','1417002581','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('74','修改信息【classid：32】【id：3】','1417004200','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('75','修改信息【classid：32】【id：2】','1417004248','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('76','修改信息【classid：32】【id：1】','1417004259','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('77','增加字段—模型id：【4】—字段名字：【bianhao】','1417004973','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('78','增加字段—模型id：【4】—字段名字：【zwmc】','1417004997','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('79','增加字段—模型id：【4】—字段名字：【gzms】','1417005099','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('80','增加字段—模型id：【4】—字段名字：【gzdd】','1417005126','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('81','增加字段—模型id：【4】—字段名字：【lxgw】','1417005151','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('82','删除字段【mid：4、fid:7】','1417005417','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('83','增加字段—模型id：【4】—字段名字：【lianxin】','1417005647','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('84','增加字段—模型id：【4】—字段名字：【gsmc】','1417005849','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('85','增加信息【classid：37】','1417006026','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('86','增加信息【classid：37】','1417006108','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('87','增加信息【classid：37】','1417006171','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('88','增加信息【classid：37】','1417006241','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('89','删除友情链接','1417007345','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('90','删除友情链接','1417007351','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('91','增加友情链接','1417007356','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('92','增加友情链接','1417007394','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('93','增加友情链接','1417007418','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('94','增加友情链接','1417007449','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('95','增加友情链接','1417007472','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('96','修改【企业合作】栏目','1417009717','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('97','修改【专注领域】栏目','1417009738','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('98','修改【服务流程】栏目','1417009755','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('99','修改【选择仕扬】栏目','1417009773','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('100','修改【其他解决方案】栏目','1417009786','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('101','修改【关于仕扬】栏目','1417009833','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('102','修改【快速消费品】栏目','1417010272','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('103','修改【大工业制造】栏目','1417010316','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('104','修改【通讯IT互联网】栏目','1417010353','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('105','修改【金融与房地产】栏目','1417010390','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('106','增加信息【classid：33】','1417010487','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('107','增加信息【classid：33】','1417010501','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('108','增加信息【classid：33】','1417010514','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('109','增加信息【classid：34】','1417010533','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('110','增加信息【classid：34】','1417010547','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('111','增加信息【classid：34】','1417010561','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('112','增加信息【classid：35】','1417010587','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('113','增加信息【classid：35】','1417010598','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('114','增加信息【classid：35】','1417010612','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('115','【admin】登录后台','1417013415','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('116','修改【快速消费品】栏目','1417013433','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('117','修改【快速消费品】栏目','1417013911','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('118','修改【大工业制造】栏目','1417014463','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('119','修改【通讯IT互联网】栏目','1417014477','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('120','修改【金融与房地产】栏目','1417014490','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('121','修改信息【classid：33】【id：6】','1417014529','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('122','修改信息【classid：33】【id：5】','1417014545','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('123','修改信息【classid：33】【id：4】','1417014560','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('124','修改信息【classid：34】【id：8】','1417014582','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('125','修改信息【classid：34】【id：7】','1417014597','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('126','修改信息【classid：35】【id：12】','1417014618','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('127','修改信息【classid：35】【id：11】','1417014632','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('128','修改信息【classid：35】【id：10】','1417014647','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('129','增加信息【classid：32】','1417014702','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('130','增加信息【classid：32】','1417014723','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('131','增加信息【classid：32】','1417014740','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('132','增加信息【classid：32】','1417014758','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('133','修改【快速消费品】栏目','1417014776','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('134','修改【大工业制造】栏目','1417014787','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('135','修改【通讯IT互联网】栏目','1417014798','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('136','修改【金融与房地产】栏目','1417014810','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('137','修改【合作客户职位】栏目','1417015614','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('138','修改【合作客户职位】栏目','1417016135','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('139','修改【最新职位】栏目','1417016501','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('140','修改【公司内部职位】栏目','1417016523','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('141','增加栏目【联系我们】','1417016601','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('142','增加自定义表单字段','1417016712','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('143','增加自定义表单字段','1417016738','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('144','增加自定义表单字段','1417016751','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('145','删除自定义表单字段','1417016762','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('146','删除自定义表单字段','1417016772','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('147','增加自定义表单字段','1417016787','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('148','增加自定义表单字段','1417016804','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('149','增加自定义表单字段','1417016820','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('150','增加自定义表单字段','1417016836','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('151','增加自定义表单字段','1417016859','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('152','增加自定义表单','1417016930','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('153','增加栏目【猎头委托】','1417017170','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('154','删除自定义表单【id：1】','1417017569','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('155','删除自定义表单字段','1417017590','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('156','增加自定义表单字段','1417017606','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('157','增加自定义表单','1417017631','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('158','修改自定义表单【id：2】','1417017859','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('159','【admin】登录后台','1417053624','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('160','修改基本设置','1417054339','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('161','修改【企业文化】栏目','1417054738','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('162','修改【联系我们】栏目','1417055193','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('163','删除栏目【id：15】和所属信息','1417055202','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('164','修改【联系我们】栏目','1417055357','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('165','增加系统模型【联系我们】','1417055447','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('166','增加字段—模型id：【6】—字段名字：【footlxwm】','1417055486','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('167','增加字段—模型id：【6】—字段名字：【copyright】','1417055545','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('168','删除栏目【id：40】和所属信息','1417055677','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('169','增加栏目【联系我们】','1417055760','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('170','删除系统模型【联系我们】','1417055859','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('171','修改【联系我们】栏目','1417055934','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('172','修改【联系我们】栏目','1417056062','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('173','更新栏目排序','1417056125','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('174','更新栏目排序','1417056176','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('175','修改【联系我们】栏目','1417056236','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('176','【admin】退出后台','1417056893','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('177','【admin】登录后台','1417057547','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('178','【admin】登录后台','1417057977','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('179','修改基本设置','1417057999','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('180','【admin】登录后台','1417058605','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('181','修改基本设置','1417058656','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('182','增加友情链接','1417059272','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('183','增加友情链接','1417059291','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('184','增加友情链接','1417059313','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('185','增加友情链接','1417059330','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('186','增加友情链接','1417059346','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('187','【admin】登录后台','1417061431','admin','192.168.1.4');[--end--]
INSERT INTO lmx_log VALUES('188','修改基本设置','1417061647','admin','192.168.1.4');[--end--]
INSERT INTO lmx_log VALUES('189','【admin】登录后台','1417062247','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('190','修改基本设置','1417062258','admin','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('191','【】退出后台','1417065078','','127.0.0.1');[--end--]
INSERT INTO lmx_log VALUES('192','【admin】登录后台','1417065086','admin','127.0.0.1');[--end--]
DROP TABLE IF EXISTS lmx_lunbo_data;[--end--]
CREATE TABLE `lmx_lunbo_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` mediumint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `tuijian` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remen` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  `lbpic` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `tuijian` (`tuijian`),
  KEY `remen` (`remen`),
  KEY `title` (`title`),
  KEY `list` (`id`,`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_lunbo_data VALUES('1','39','轮播1','','','1416990597','','0','0','20','/file/ad/20141126/201411261623437086.jpg');[--end--]
INSERT INTO lmx_lunbo_data VALUES('2','39','轮播2','','','1416990623','','0','0','70','/file/ad/20141126/201411261623437086.jpg');[--end--]
INSERT INTO lmx_lunbo_data VALUES('3','39','轮播3','','','1416990643','','0','0','52','/file/ad/20141126/201411261623437086.jpg');[--end--]
DROP TABLE IF EXISTS lmx_lunbo_data_1;[--end--]
CREATE TABLE `lmx_lunbo_data_1` (
  `uid` int(10) unsigned NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_module;[--end--]
CREATE TABLE `lmx_module` (
  `mid` mediumint(5) unsigned NOT NULL AUTO_INCREMENT,
  `mname` varchar(100) NOT NULL,
  `tab` varchar(50) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`mid`),
  KEY `tab` (`tab`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_module VALUES('1','产品模型','product_data','');[--end--]
INSERT INTO lmx_module VALUES('2','新闻模型','news_data','');[--end--]
INSERT INTO lmx_module VALUES('3','成功案例','anli_data','成功案例');[--end--]
INSERT INTO lmx_module VALUES('4','职位','zhiwei_data','');[--end--]
INSERT INTO lmx_module VALUES('5','轮播广告','lunbo_data','');[--end--]
DROP TABLE IF EXISTS lmx_news_data;[--end--]
CREATE TABLE `lmx_news_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` mediumint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `tuijian` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remen` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `title` (`title`),
  KEY `list` (`id`,`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_news_data_1;[--end--]
CREATE TABLE `lmx_news_data_1` (
  `uid` int(10) unsigned NOT NULL,
  `content` mediumtext NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_product_data;[--end--]
CREATE TABLE `lmx_product_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` mediumint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `remen` tinyint(1) NOT NULL DEFAULT '0',
  `tuijian` tinyint(1) NOT NULL DEFAULT '0',
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  `duotp` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `classid` (`classid`),
  KEY `list` (`id`,`classid`),
  KEY `remen` (`remen`),
  KEY `tuijian` (`tuijian`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_product_data_1;[--end--]
CREATE TABLE `lmx_product_data_1` (
  `uid` int(10) unsigned NOT NULL,
  `content` mediumtext NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_search;[--end--]
CREATE TABLE `lmx_search` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keywords` varchar(255) NOT NULL,
  `classid` int(10) unsigned NOT NULL DEFAULT '0',
  `mid` int(5) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL,
  `url` text NOT NULL,
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`),
  KEY `keywords` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_singlecon;[--end--]
CREATE TABLE `lmx_singlecon` (
  `classid` mediumint(5) NOT NULL,
  `content` mediumtext NOT NULL,
  KEY `classid` (`classid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_singlecon VALUES('1','');[--end--]
INSERT INTO lmx_singlecon VALUES('41','<p>猎头委托</p>');[--end--]
INSERT INTO lmx_singlecon VALUES('3','<p>上海仕扬企业管理咨询有限公司是一间最具专业能力的大型人力资源顾问公司，主要事业定位于高端人力资源领域的猎头服务。拓优成立于1999年，经由多年的发展和积累，拓优的分支已遍布北京、上海、广州、深圳、武汉、济南、西安、长沙、成都、南京、青岛，由200多名专业猎头顾问形成了稳定的服务团队。</p><p>自成立以来，拓优向超过五分之一的五百强企业提供过专业的猎头服务，90%以上的客户都来自于行业领先者。通过合作，拓优与客户之间建立了基于信任和绩效的稳健关系。</p><p>寻访之外，拓优持续地对客户产品知识、行业竞争信息、竞争格局变化、组织风格、企业文化、候选人偏好等等的深度研究，使拓优总能迅捷、精准地响应客户的需求，超过85%的客户把拓优猎头作为“first vendor”，多次被客户评价为“神奇”。而对顾问扎实的猎头专业训练、严格的流程管理和质量控制体系较大程度上消除了行业之病——顾问差异所导致的服务质量不稳定，使拓优猎头持续完美地向客户提供“专业、迅捷、贴身的个性化深度服务”</p><p></p>');[--end--]
INSERT INTO lmx_singlecon VALUES('4','<p>自成立以来，拓优向超过五分之一的五百强企业提供过专业的猎头服务，90%以上的客户都来自于行业领先者。通过合作，拓优与客户之间建立了基于信任和绩效的稳健关系。</p>');[--end--]
INSERT INTO lmx_singlecon VALUES('16','');[--end--]
INSERT INTO lmx_singlecon VALUES('27','<p>资料更新中</p>');[--end--]
INSERT INTO lmx_singlecon VALUES('26','');[--end--]
INSERT INTO lmx_singlecon VALUES('28','<p>资料更新中</p>');[--end--]
INSERT INTO lmx_singlecon VALUES('29','<p>资料更新中</p><p></p>');[--end--]
INSERT INTO lmx_singlecon VALUES('30','<p>资料更新中</p><p></p>');[--end--]
INSERT INTO lmx_singlecon VALUES('42','<p>上海：虹口区大连路535号3楼A36<br/>北京：朝阳区朝阳门外大街18号丰联广场A座1906<br/>武汉：武昌区中南路7号中商广场3402<br/>电话：021-65356632-9036</p>');[--end--]
DROP TABLE IF EXISTS lmx_slide;[--end--]
CREATE TABLE `lmx_slide` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_slide VALUES('1','首页焦点图','');[--end--]
DROP TABLE IF EXISTS lmx_slide_data;[--end--]
CREATE TABLE `lmx_slide_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `img` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_slide_data VALUES('1','1','/file/slide/20141126/201411261615212753.jpg','','0','');[--end--]
INSERT INTO lmx_slide_data VALUES('2','1','/file/slide/20141126/201411261615532055.jpg','','0','');[--end--]
DROP TABLE IF EXISTS lmx_tags;[--end--]
CREATE TABLE `lmx_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `tem` varchar(255) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pagenum` int(10) unsigned NOT NULL DEFAULT '10',
  `num` int(10) unsigned NOT NULL DEFAULT '0',
  `classid` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `remen` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `tuijian` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `remen` (`remen`),
  KEY `tuijian` (`tuijian`),
  KEY `classid` (`classid`),
  KEY `list` (`id`,`num`,`remen`,`tuijian`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_tags_info;[--end--]
CREATE TABLE `lmx_tags_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `infoid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `classid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `list` (`id`,`uid`,`classid`,`infoid`),
  KEY `uid` (`uid`),
  KEY `info` (`infoid`,`classid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_user;[--end--]
CREATE TABLE `lmx_user` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `pwd` char(32) NOT NULL,
  `currtime` int(10) NOT NULL,
  `currip` varchar(100) NOT NULL,
  `lasttime` int(10) unsigned NOT NULL,
  `lastip` varchar(100) NOT NULL,
  `num` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `errortime` int(10) unsigned NOT NULL,
  `num1` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `errortime1` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_user VALUES('1','admin','e4df6ecc582306e7df6a492aa31d2d09','1417065086','127.0.0.1','1417062247','127.0.0.1','0','1417058549','0','0');[--end--]
DROP TABLE IF EXISTS lmx_userlog;[--end--]
CREATE TABLE `lmx_userlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_userlog VALUES('1','admin','127.0.0.1','1416972878');[--end--]
INSERT INTO lmx_userlog VALUES('2','admin','127.0.0.1','1416972951');[--end--]
INSERT INTO lmx_userlog VALUES('3','admin','127.0.0.1','1416985255');[--end--]
INSERT INTO lmx_userlog VALUES('4','admin','127.0.0.1','1416988223');[--end--]
INSERT INTO lmx_userlog VALUES('5','admin','127.0.0.1','1417000242');[--end--]
INSERT INTO lmx_userlog VALUES('6','admin','127.0.0.1','1417013415');[--end--]
INSERT INTO lmx_userlog VALUES('7','admin','127.0.0.1','1417053624');[--end--]
INSERT INTO lmx_userlog VALUES('8','admin','127.0.0.1','1417057547');[--end--]
INSERT INTO lmx_userlog VALUES('9','admin','127.0.0.1','1417057977');[--end--]
INSERT INTO lmx_userlog VALUES('10','admin','127.0.0.1','1417058605');[--end--]
INSERT INTO lmx_userlog VALUES('11','admin','192.168.1.4','1417061431');[--end--]
INSERT INTO lmx_userlog VALUES('12','admin','127.0.0.1','1417062247');[--end--]
INSERT INTO lmx_userlog VALUES('13','admin','127.0.0.1','1417065086');[--end--]
DROP TABLE IF EXISTS lmx_zhiwei_data;[--end--]
CREATE TABLE `lmx_zhiwei_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` mediumint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `tuijian` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remen` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `click` int(10) unsigned NOT NULL DEFAULT '0',
  `bianhao` varchar(255) NOT NULL,
  `zwmc` varchar(255) NOT NULL,
  `gzms` mediumtext NOT NULL,
  `gzdd` varchar(255) NOT NULL,
  `lxgw` varchar(255) NOT NULL,
  `lianxin` varchar(255) NOT NULL,
  `gsmc` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `tuijian` (`tuijian`),
  KEY `remen` (`remen`),
  KEY `title` (`title`),
  KEY `list` (`id`,`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;[--end--]
INSERT INTO lmx_zhiwei_data VALUES('1','37','盛旅置业（上海）有限公司','','','1417005936','','1','0','61','ZW0001','IOS开发工程师','<p>岗位职责：<br/>1、负责IOS 主客户端及应用框架的开发和维护；<br/>2、负责平台相关的调试，配置以及Bug的修正；<br/>3、负责平台开发与接入相关的文档、手册、流程编写整理。<br/><br/>任职要求：<br/>1、计算机相关专业本科及以上学历，5年以上软件开发经验，至少3年以上IOS平台开发经验； <br/>2、能独立承担开发高性能的IOS应用，熟练掌握多线程程序设计技术，IOS平台UI、线程、消息和进程通信机制；<br/>3、熟练掌握Object-C、C++和面向对象程序设计，对设计模式有深入理解；<br/>4、对移动开发有浓厚的兴趣，有良好的沟通能力和团队协作能力，能够承受较大的工作压力；<br/>5、具有知名移动平台开发经验者优先。</p>','上海','程小东','15W','盛旅置业（上海）有限公司');[--end--]
INSERT INTO lmx_zhiwei_data VALUES('2','37','玖龙纸业(控股)有限公司','','','1417006034','','1','0','65','XX002','物流运输经理','<p>1、负责运输组、进出口、成品库的统筹管理工作；<br/>2、拟定、完善部门各类考核方案，报公司、集团审批后执行、落实；<br/>3、制定和完善部门各岗位职责和工作流程；<br/>4、统筹协调原料、运输、进出口、成品库间的运行，配合生产、热电等其他相关部门开展工作；<br/>5、协调海关、国检、海事、交委、交警、路政等政府部门的相关工作；<br/>6、部门培训、活动的计划和组织落实；<br/>7、按时完成公司临时安排的工作任务；<br/>任职要求：<br/>1、大专及以上学历，物流管理等相关专业；<br/>2、有5年以上大型物流管理工作经验或3年以上集团内相关管理岗位工作经验；<br/>3、具备良好的沟通协调能力，团队意识强，责任心强；<br/>4、吃苦耐劳，有良好的职业操守和抗压能力。</p>','合肥','李小明','10W','玖龙纸业(控股)有限公司');[--end--]
INSERT INTO lmx_zhiwei_data VALUES('3','37','宜信卓越财富投资管理（北京）有限公司','','','1417006124','','1','0','98','JS0003','高级理财经理','<p>理财经理：<br/><br/>岗位职责<br/>1.在金融市场上，进行潜在客户开发，为客户建立、提供专业的资产管理咨询服务；<br/>2.推广公司财富管理产品，为客户提供适用的高端产品组合，为理财客户提供专业化的理财服务；<br/>3.根据一线工作了解到的客户反馈，向公司提出产品及流程优化建议；<br/>4.完成销售经理制定的销售目标，根据销售经理的要求按时保质完成销售报告。<br/><br/><br/>职位要求<br/>1.本科以上学历，营销、管理、金融等专业优先；<br/>2.2年以上工作经验，最好有银行、保险、证券、市场营销、房地产等从业人员；<br/>3.强烈的时间观念和服务意识，良好的客户沟通、人际交往及维系客户关系的能力； <br/>4.敏锐的市场洞察力和准确的客户分析能力，能够有效开发客户资源；<br/>5.有广泛的社会关系网络和客户人脉资源，具有开发大客户经验者优先；<br/>6.极强的中高端客户市场开拓能力以及良好的客户沟通能力、关系管理能力以及优秀的营销技巧。<br/><br/><br/>福利待遇<br/>1. 公司提供舒适的办公环境，良好的职业发展规划，完善的培训学习机制。<br/>2. 入职即缴纳五险一金，转正后增加商业保险。 <br/>3. 工作时间：周一至周五，双休日休息；享受一切法定假日。 <br/>4. 工作突出者享受丰厚的收入回报和快速广阔的晋升空间。<br/>5. 业绩突出者每年享受至少2次海外旅游及培训学习的机会。</p>','广东','孙小红','20W','宜信卓越财富投资管理（北京）有限公司');[--end--]
INSERT INTO lmx_zhiwei_data VALUES('4','37','玖龙纸业(控股)有限公司','','','1417006178','','1','0','45','JS00004','技术副总工','<p>1、负责集团整体工程技术工作，对于涉及工程技术方面的工作进行统筹安排；<br/>2、贯彻集团公司领导的管理理念，根据集团公司的企业文化，在集团公司现有的规章管理制度框架下，做好新工程技术规范及监督执行、图纸设计、图纸方案审核等工作；<br/>3、结合公司标准化、系统化的发展要求，制定集团建筑作法统一标准，并检查督促执行结果；<br/>4、及时了解国内外最先进的工程技术，完善公司现场有关工程的技术规范，并制订新的技术标准；<br/>5、负责重大项目的建设方案与策划，招标技术文件的审核监督工作；<br/>6、负责集团工程土建类图纸、施工方案招标前的审核；<br/>7、抽查各项目是否按图纸、国家规范、公司规定进行施工；<br/>8、完成上级交办的其他相关事项。<br/>其他任职要求：<br/>1、本科及以上学历，土木工程及相关专业；<br/>2、有大型建筑企业5年以上工作管理经验，一级建造师；有国家注册结构工程师优先；<br/>3、有一定的分析和预测能力；<br/>4、思维敏捷、善于分析问题，文字功底较好。</p>','北京','李小明','30W','玖龙纸业(控股)有限公司');[--end--]
DROP TABLE IF EXISTS lmx_zhiwei_data_1;[--end--]
CREATE TABLE `lmx_zhiwei_data_1` (
  `uid` int(10) unsigned NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_zt;[--end--]
CREATE TABLE `lmx_zt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `tem` varchar(255) NOT NULL,
  `islist` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL,
  `images` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pagenum` int(10) unsigned NOT NULL,
  `num` int(10) unsigned NOT NULL DEFAULT '0',
  `domain` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `sort` (`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
DROP TABLE IF EXISTS lmx_zt_info;[--end--]
CREATE TABLE `lmx_zt_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `infoid` int(11) NOT NULL,
  `classid` mediumint(5) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `remen` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `tuijian` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `infoid` (`infoid`),
  KEY `uid` (`uid`),
  KEY `list` (`id`,`infoid`,`uid`,`classid`,`remen`,`tuijian`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;[--end--]
